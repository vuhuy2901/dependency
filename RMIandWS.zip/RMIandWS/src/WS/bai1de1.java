package WS;

import java.util.*;
import java.time.*;
import java.math.*;
import java.util.stream.*;

// De 1, bai 1 - Phan tich thua so nguyen to
// qCode trong tai lieu on thi 2024-2025: TwZpbqUg
public class bai1de1 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "TwZpbqUg";
        SoapDataService sk = new DataService().getPort(SoapDataService.class);
        List<Integer> a = sk.getData(msv, qcode);
        if (a == null) { System.out.println("Server tra ve null; kiem tra qCode"); return; }
        List<String> result = new ArrayList<>();
        for (int x : a) {
            int n = x;
            List<String> factors = new ArrayList<>();
            for (int d = 2; d <= n / d; d++) {
                while (n % d == 0) {
                    factors.add(String.valueOf(d));
                    n /= d;
                }
            }
            if (n > 1) factors.add(String.valueOf(n));
            // Tai lieu cho vi du: 28 -> "2, 2, 7"; moi so trong input ung voi 1 chuoi.
            result.add(String.join(", ", factors));
        }
        sk.submitDataStringArray(msv, qcode, result);
        System.out.println(result);
    }
}
