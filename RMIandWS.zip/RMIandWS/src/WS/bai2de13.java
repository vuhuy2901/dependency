package WS;

import java.util.*;
import java.time.*;
import java.math.*;
import java.util.stream.*;

// De 13, bai 2 - Loc hoa don cua khach hang tong gia tri cao nhat
// qCode trong tai lieu on thi 2024-2025: CuW1L0ev
public class bai2de13 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "CuW1L0ev";
        SoapObjectService sk = new ObjectService().getPort(SoapObjectService.class);
        List<Order> a = sk.requestListOrder(msv, qcode);
        if (a == null) { System.out.println("Server tra ve null"); return; }
        Map<String, Double> total = new HashMap<>();
        for (Order o : a) {
            total.merge(o.getCustomerId(), (double) o.getAmount(), Double::sum);
        }
        double max = total.values().stream().mapToDouble(Double::doubleValue).max().orElse(Double.NaN);
        List<Order> result = new ArrayList<>();
        for (Order o : a) {
            // Giu TAT CA don cua nhung khach hang co tong gia tri don hang cao nhat.
            if (Double.compare(total.get(o.getCustomerId()), max) == 0) result.add(o);
        }
        sk.submitListOrder(msv, qcode, result);
        System.out.println("So don: " + result.size());
    }
}
