package WS;

import java.util.*;
import java.time.*;
import java.math.*;
import java.util.stream.*;

// De 11, bai 1 - Loc khach hang totalSpent va purchaseCount
// qCode trong tai lieu on thi 2024-2025: lgKj7lIF
public class bai1de11 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "lgKj7lIF";
        SoapObjectService sk = new ObjectService().getPort(SoapObjectService.class);
        List<Customer> a = sk.requestListCustomer(msv, qcode);
        if (a == null) { System.out.println("Server tra ve null"); return; }
        List<Customer> result = new ArrayList<>(a);
        // Theo PDF cu: >5000 va >=5. Bai live qCode KHAC tung dung >500 va >=3.
        result.removeIf(c -> c.getTotalSpent() <= 5000 || c.getPurchaseCount() < 5);
        sk.submitListCustomer(msv, qcode, result);
        System.out.println("So khach hang: " + result.size());
    }
}
