package WS;

import java.util.*;
import java.time.*;
import java.math.*;
import java.util.stream.*;

// De 8, bai 1 - Loc du an >=80 phan tram den han trong 15 ngay
// qCode trong tai lieu on thi 2024-2025: R6UOuyyE
public class bai1de8 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "R6UOuyyE";
        SoapObjectService sk = new ObjectService().getPort(SoapObjectService.class);
        List<Project> a = sk.requestListProject(msv, qcode);
        if (a == null) { System.out.println("Server tra ve null"); return; }
        LocalDate today = LocalDate.now();
        LocalDate to = today.plusDays(15);
        List<Project> result = new ArrayList<>();
        for (Project p : a) {
            if (p.getDueDate() == null) continue;
            LocalDate due = p.getDueDate().toGregorianCalendar().toZonedDateTime().toLocalDate();
            if (p.getCompletionPercentage() >= 80.0 &&
                    !due.isBefore(today) && !due.isAfter(to)) {
                result.add(p);
            }
        }
        sk.submitListProject(msv, qcode, result);
        System.out.println("So du an: " + result.size());
    }
}
