package WS;

import java.util.*;
import java.time.*;
import java.math.*;
import java.util.stream.*;

// De 2, bai 3 - Tinh gia cuoi cung ProductY
// qCode trong tai lieu on thi 2024-2025: itT8hvxF
public class bai3de2 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "itT8hvxF";
        SoapObjectService sk = new ObjectService().getPort(SoapObjectService.class);
        ProductY p = sk.requestProductY(msv, qcode);
        if (p == null) { System.out.println("Server tra ve null"); return; }
        double value = p.getPrice() * (1 + p.getTaxRate() / 100.0)
                      * (1 - p.getDiscount() / 100.0);
        p.setFinalPrice((float) value); // WSDL thong thuong sinh float cho finalPrice
        sk.submitProductY(msv, qcode, p);
        System.out.println("finalPrice=" + p.getFinalPrice());
    }
}
