package WS;

import java.util.*;
import java.time.*;
import java.math.*;
import java.util.stream.*;

// De 3, bai 3 - Loc sinh vien nhom A va D
// qCode trong tai lieu on thi 2024-2025: qNfIMvid
public class bai3de3 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "qNfIMvid";
        SoapObjectService sk = new ObjectService().getPort(SoapObjectService.class);
        List<Student> a = sk.requestListStudent(msv, qcode);
        if (a == null) { System.out.println("Server tra ve null"); return; }
        List<Student> result = new ArrayList<>();
        for (Student s : a) {
            // A: diem >= 8; D: diem < 5.
            if (s.getScore() >= 8.0 || s.getScore() < 5.0) result.add(s);
        }
        sk.submitListStudent(msv, qcode, result);
        System.out.println("So sinh vien A/D: " + result.size());
    }
}
