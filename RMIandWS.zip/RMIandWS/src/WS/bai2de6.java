package WS;

import java.util.*;
import java.time.*;
import java.math.*;
import java.util.stream.*;

// De 6, bai 2 - Chuan hoa Pascal camel snake case
// qCode trong tai lieu on thi 2024-2025: sBQjqANT
public class bai2de6 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "sBQjqANT";
        SoapCharacterService sk = new CharacterService().getPort(SoapCharacterService.class);
        String s = sk.requestString(msv, qcode);
        if (s == null) { System.out.println("Server tra ve null"); return; }
        String[] words = s.trim().split("[\\s_]+");
        StringBuilder pascal = new StringBuilder();
        StringBuilder camel = new StringBuilder();
        StringJoiner snake = new StringJoiner("_");
        for (int i = 0; i < words.length; i++) {
            String word = words[i].toLowerCase(Locale.ROOT);
            if (word.isEmpty()) continue;
            String cap = Character.toUpperCase(word.charAt(0)) + word.substring(1);
            pascal.append(cap);
            camel.append(i == 0 ? word : cap);
            snake.add(word);
        }
        List<String> result = Arrays.asList(pascal.toString(), camel.toString(), snake.toString());
        sk.submitCharacterStringArray(msv, qcode, result);
        System.out.println(result);
    }
}
