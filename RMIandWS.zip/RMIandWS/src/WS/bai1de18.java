package WS;

import java.util.*;
import java.time.*;
import java.math.*;
import java.util.stream.*;

// De 18, bai 1 - Xen ke chan le bat dau bang chan
// qCode trong tai lieu on thi 2024-2025: 0BEtJAT9
public class bai1de18 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "0BEtJAT9";
        SoapDataService sk = new DataService().getPort(SoapDataService.class);
        List<Integer> a = sk.getData(msv, qcode);
        if (a == null) { System.out.println("Server tra ve null"); return; }
        List<Integer> even = new ArrayList<>(), odd = new ArrayList<>();
        for (int x : a) {
            if (x % 2 == 0) even.add(x);
            else odd.add(x);
        }
        List<Integer> result = new ArrayList<>();
        int i = 0, j = 0;
        while (i < even.size() && j < odd.size()) {
            result.add(even.get(i++));
            result.add(odd.get(j++));
        }
        while (i < even.size()) result.add(even.get(i++));
        while (j < odd.size()) result.add(odd.get(j++));
        sk.submitDataIntArray(msv, qcode, result);
        System.out.println(result);
    }
}
