package WS;

import java.util.*;
import java.time.*;
import java.math.*;
import java.util.stream.*;

// De 1, bai 3 - Loc sinh vien diem cao nhat tung mon
// qCode trong tai lieu on thi 2024-2025: 2RjVBzv0
public class bai3de1 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "2RjVBzv0";
        SoapObjectService sk = new ObjectService().getPort(SoapObjectService.class);
        List<StudentY> a = sk.requestListStudentY(msv, qcode);
        if (a == null) { System.out.println("Server tra ve null"); return; }
        Map<String, Float> maxScore = new HashMap<>();
        for (StudentY s : a) {
            maxScore.merge(s.getSubject(), s.getScore(), Math::max);
        }
        List<StudentY> result = new ArrayList<>();
        for (StudentY s : a) {
            // Neu dong diem cao nhat cung mon thi giu ca hai; bao toan thu tu goc.
            if (Float.compare(s.getScore(), maxScore.get(s.getSubject())) == 0) result.add(s);
        }
        sk.submitListStudentY(msv, qcode, result);
        System.out.println("So sinh vien: " + result.size());
    }
}
