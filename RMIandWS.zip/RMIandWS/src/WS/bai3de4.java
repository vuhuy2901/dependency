package WS;

import java.util.*;
import java.time.*;
import java.math.*;
import java.util.stream.*;

// De 4, bai 3 - Sap xep nhan vien theo tham nien
// qCode trong tai lieu on thi 2024-2025: vewbvojZ
public class bai3de4 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "vewbvojZ";
        SoapObjectService sk = new ObjectService().getPort(SoapObjectService.class);
        List<EmployeeY> a = sk.requestListEmployeeY(msv, qcode);
        if (a == null) { System.out.println("Server tra ve null"); return; }
        List<EmployeeY> result = new ArrayList<>(a);
        // wsimport thuong sinh XMLGregorianCalendar cho truong Date trong WSDL.
        result.sort(Comparator.comparingLong(
                x -> x.getStartDate().toGregorianCalendar().getTimeInMillis()));
        // List.sort on dinh, nen cung ngay giu thu tu ban dau.
        sk.submitListEmployeeY(msv, qcode, result);
        System.out.println("So nhan vien: " + result.size());
    }
}
