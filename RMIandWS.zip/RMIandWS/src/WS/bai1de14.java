package WS;

import java.util.*;
import java.time.*;
import java.math.*;
import java.util.stream.*;

// De 14, bai 1 - Doi sang he bat phan va hexa chu hoa
// qCode trong tai lieu on thi 2024-2025: QBDJ1GGL
public class bai1de14 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "QBDJ1GGL";
        SoapDataService sk = new DataService().getPort(SoapDataService.class);
        List<Integer> a = sk.getData(msv, qcode);
        if (a == null) { System.out.println("Server tra ve null"); return; }
        List<String> result = new ArrayList<>();
        for (int x : a) {
            String oct = Integer.toOctalString(x);
            String hex = Integer.toHexString(x).toUpperCase(Locale.ROOT);
            result.add(oct + "|" + hex);
        }
        sk.submitDataStringArray(msv, qcode, result);
        System.out.println(result);
    }
}
