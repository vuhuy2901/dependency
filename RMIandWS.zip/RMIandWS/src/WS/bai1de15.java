package WS;

import java.util.*;
import java.time.*;
import java.math.*;
import java.util.stream.*;

// De 15, bai 1 - Loai bo trung lap giu thu tu
// qCode trong tai lieu on thi 2024-2025: E2Axwwf3
public class bai1de15 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "E2Axwwf3";
        SoapDataService sk = new DataService().getPort(SoapDataService.class);
        List<Integer> a = sk.getData(msv, qcode);
        if (a == null) { System.out.println("Server tra ve null"); return; }
        List<Integer> result = new ArrayList<>(new LinkedHashSet<>(a));
        sk.submitDataIntArray(msv, qcode, result);
        System.out.println(result);
    }
}
