package WS;

import java.util.*;
import java.time.*;
import java.math.*;
import java.util.stream.*;

// De 5, bai 1 - Tu dai nhat va tu ngan nhat trong mot chuoi
// qCode trong tai lieu on thi 2024-2025: 9n2rfqST
public class bai1de5 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "9n2rfqST";
        SoapCharacterService sk = new CharacterService().getPort(SoapCharacterService.class);
        String s = sk.requestString(msv, qcode);
        if (s == null || s.trim().isEmpty()) { System.out.println("Khong co du lieu"); return; }
        String[] words = s.trim().split("\\s+");
        String longest = words[0], shortest = words[0];
        for (String word : words) {
            if (word.length() > longest.length()) longest = word;
            if (word.length() < shortest.length()) shortest = word;
        }
        String result = longest + "; " + shortest;  // De 5: co dau cach sau dau ;
        sk.submitCharacterString(msv, qcode, result);
        System.out.println(result);
    }
}
