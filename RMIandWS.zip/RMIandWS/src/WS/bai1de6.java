package WS;

import java.util.*;
import java.time.*;
import java.math.*;
import java.util.stream.*;

// De 6, bai 1 - Ghep cac so thanh so lon nhat
// qCode trong tai lieu on thi 2024-2025: RiRH8wfk
public class bai1de6 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "RiRH8wfk";
        SoapDataService sk = new DataService().getPort(SoapDataService.class);
        List<Integer> a = sk.getData(msv, qcode);
        if (a == null) { System.out.println("Server tra ve null"); return; }
        List<String> b = new ArrayList<>();
        for (int x : a) b.add(String.valueOf(x));
        b.sort((x, y) -> (y + x).compareTo(x + y));
        String result = String.join("", b);
        sk.submitDataString(msv, qcode, result);
        System.out.println(result);
    }
}
