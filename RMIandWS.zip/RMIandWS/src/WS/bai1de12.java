package WS;

import java.util.*;
import java.time.*;
import java.math.*;
import java.util.stream.*;

// De 12, bai 1 - Xoay phai mang ky tu bang do dai mang
// qCode trong tai lieu on thi 2024-2025: YDcPHFgN
public class bai1de12 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "YDcPHFgN";
        SoapCharacterService sk = new CharacterService().getPort(SoapCharacterService.class);
        List<Integer> raw = sk.requestCharacter(msv, qcode);
        if (raw == null) { System.out.println("Server tra ve null"); return; }
        List<Integer> result = new ArrayList<>(raw);
        // WSDL thuc te tra List<Integer> (ma ky tu), khong phai List<Character>.
        Collections.rotate(result, result.size());
        // Can chu y: xoay n phan tu dung n lan KHONG thay doi thu tu!
        // Vi du trong PDF noi xoay 4 phan tu 4 lan thanh [b,c,d,a], bi mau thuan.
        sk.submitCharacterCharArray(msv, qcode, result);
        System.out.println(result);
    }
}
