package WS;

import java.util.*;
import java.time.*;
import java.math.*;
import java.util.stream.*;

// De 4, bai 1 - Liet ke va dem uoc cua phan nguyen
// qCode trong tai lieu on thi 2024-2025: nhFjYg0F
public class bai1de4 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "nhFjYg0F";
        SoapDataService sk = new DataService().getPort(SoapDataService.class);
        double x = sk.getDataDouble(msv, qcode);
        int n = (int) x; // Lay phan nguyen, voi input duong nhu vi du
        List<Integer> factors = new ArrayList<>();
        for (int i = 1; i <= n; i++) {
            if (n % i == 0) factors.add(i);
        }
        List<Integer> result = new ArrayList<>();
        result.add(factors.size());
        result.addAll(factors);
        sk.submitDataIntArray(msv, qcode, result);
        System.out.println(result);
    }
}
