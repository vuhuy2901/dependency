package WS;

import java.util.*;
import java.time.*;
import java.math.*;
import java.util.stream.*;

// De 10, bai 1 - Nhom tu theo so nguyen am
// qCode trong tai lieu on thi 2024-2025: 32He7sZg
public class bai1de10 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "32He7sZg";
        SoapCharacterService sk = new CharacterService().getPort(SoapCharacterService.class);
        List<String> a = sk.requestStringArray(msv, qcode);
        if (a == null) { System.out.println("Server tra ve null"); return; }
        Map<Integer, List<String>> groups = new TreeMap<>();
        for (String s : a) {
            int count = 0;
            for (char c : s.toLowerCase(Locale.ROOT).toCharArray()) {
                if ("aeiou".indexOf(c) >= 0) count++;
            }
            groups.computeIfAbsent(count, k -> new ArrayList<>()).add(s);
        }
        List<String> result = new ArrayList<>();
        for (List<String> group : groups.values()) {
            Collections.sort(group);
            // Theo van ban de cu: 1 phan tu result la 1 chuoi gop ca nhom.
            // Bai live tren DB-Lab da co lan AC theo dang phang:
            // neu WA voi cau hoi CU THE, thu result.addAll(group) thay vi join.
            result.add(String.join(", ", group));
        }
        sk.submitCharacterStringArray(msv, qcode, result);
        System.out.println(result);
    }
}
