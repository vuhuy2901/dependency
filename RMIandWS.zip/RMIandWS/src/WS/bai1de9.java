package WS;

import java.util.*;
import java.time.*;
import java.math.*;
import java.util.stream.*;

// De 9, bai 1 - Chuyen double thanh phan so toi gian
// qCode trong tai lieu on thi 2024-2025: ny8Fb8BU
public class bai1de9 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "ny8Fb8BU";
        SoapDataService sk = new DataService().getPort(SoapDataService.class);
        double value = sk.getDataDouble(msv, qcode);
        // Dung dang thap phan cua double de tranh loi dau phay dong.
        BigDecimal decimal = BigDecimal.valueOf(value).stripTrailingZeros();
        BigInteger numerator = decimal.unscaledValue();
        BigInteger denominator = BigInteger.ONE;
        int scale = decimal.scale();
        if (scale > 0) denominator = BigInteger.TEN.pow(scale);
        if (scale < 0) numerator = numerator.multiply(BigInteger.TEN.pow(-scale));
        BigInteger gcd = numerator.abs().gcd(denominator);
        numerator = numerator.divide(gcd);
        denominator = denominator.divide(gcd);
        // WSDL nhan List<Integer>; neu mau/tu vuot int thi de khong ro cach xu ly.
        List<Integer> result = Arrays.asList(numerator.intValueExact(), denominator.intValueExact());
        sk.submitDataIntArray(msv, qcode, result);
        System.out.println(result);
    }
}
