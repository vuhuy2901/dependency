package WS;

import java.util.*;
import java.time.*;
import java.math.*;
import java.util.stream.*;

// De 5, bai 3 - Loc khach hang khong giao dich 6 thang
// qCode trong tai lieu on thi 2024-2025: aYiLQ3wo
public class bai3de5 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "aYiLQ3wo";
        SoapObjectService sk = new ObjectService().getPort(SoapObjectService.class);
        List<CustomerY> a = sk.requestListCustomerY(msv, qcode);
        if (a == null) { System.out.println("Server tra ve null"); return; }
        LocalDate cutoff = LocalDate.now().minusMonths(6);
        List<CustomerY> result = new ArrayList<>();
        for (CustomerY c : a) {
            if (c.getLastTransactionDate() == null ||
                c.getLastTransactionDate().toGregorianCalendar()
                    .toZonedDateTime().toLocalDate().isBefore(cutoff)) {
                result.add(c);
            }
        }
        sk.submitListCustomerY(msv, qcode, result);
        System.out.println("Khach hang khong hoat dong: " + result.size());
    }
}
