package WS;

import java.util.*;
import java.time.*;
import java.math.*;
import java.util.stream.*;

// De 7, bai 2 - Loc don pending processing 30 ngay gan day
// qCode trong tai lieu on thi 2024-2025: 46WF6Fg5
public class bai2de7 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "46WF6Fg5";
        SoapObjectService sk = new ObjectService().getPort(SoapObjectService.class);
        List<OrderY> a = sk.requestListOrderY(msv, qcode);
        if (a == null) { System.out.println("Server tra ve null"); return; }
        LocalDate today = LocalDate.now();
        LocalDate from = today.minusDays(30);
        List<OrderY> result = new ArrayList<>();
        for (OrderY o : a) {
            String status = o.getStatus();
            if (status == null || o.getOrderDate() == null) continue;
            boolean urgent = status.equalsIgnoreCase("pending") || status.equalsIgnoreCase("processing");
            LocalDate date = o.getOrderDate().toGregorianCalendar().toZonedDateTime().toLocalDate();
            if (urgent && !date.isBefore(from) && !date.isAfter(today)) result.add(o);
        }
        sk.submitListOrderY(msv, qcode, result);
        System.out.println("So don uu tien: " + result.size());
    }
}
