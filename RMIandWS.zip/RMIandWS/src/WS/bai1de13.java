package WS;

import java.util.*;
import java.time.*;
import java.math.*;
import java.util.stream.*;

// De 13, bai 1 - Chuyen mang so sang he nhi phan
// qCode trong tai lieu on thi 2024-2025: 2jS1DTpU
public class bai1de13 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "2jS1DTpU";
        SoapDataService sk = new DataService().getPort(SoapDataService.class);
        List<Integer> a = sk.getData(msv, qcode);
        if (a == null) { System.out.println("Server tra ve null"); return; }
        List<String> result = new ArrayList<>();
        for (int x : a) result.add(Integer.toBinaryString(x));
        sk.submitDataStringArray(msv, qcode, result);
        System.out.println(result);
    }
}
