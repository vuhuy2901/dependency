package WS;

import java.util.*;
import java.time.*;
import java.math.*;
import java.util.stream.*;

// De 2, bai 1 - Dem tan suat so nguyen
// qCode trong tai lieu on thi 2024-2025: TU4ULIgh
public class bai1de2 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "TU4ULIgh";
        SoapDataService sk = new DataService().getPort(SoapDataService.class);
        List<Integer> a = sk.getData(msv, qcode);
        if (a == null) { System.out.println("Server tra ve null"); return; }
        Map<Integer, Integer> freq = new TreeMap<>();  // Theo ghi chu: sap xep tang dan
        for (int x : a) freq.put(x, freq.getOrDefault(x, 0) + 1);
        List<String> result = new ArrayList<>();
        for (Map.Entry<Integer, Integer> e : freq.entrySet()) {
            result.add(e.getKey() + ", " + e.getValue());
        }
        sk.submitDataStringArray(msv, qcode, result);
        System.out.println(result);
    }
}
