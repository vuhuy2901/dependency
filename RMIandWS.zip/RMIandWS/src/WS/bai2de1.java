package WS;

import java.util.*;
import java.time.*;
import java.math.*;
import java.util.stream.*;

// De 1, bai 2 - Sap xep chuoi theo so nguyen am
// qCode trong tai lieu on thi 2024-2025: mDN1MFUJ
public class bai2de1 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "mDN1MFUJ";
        SoapCharacterService sk = new CharacterService().getPort(SoapCharacterService.class);
        List<String> a = sk.requestStringArray(msv, qcode);
        if (a == null) { System.out.println("Server tra ve null"); return; }
        List<String> result = new ArrayList<>(a);
        // List.sort on dinh: cac tu co cung so nguyen am giu thu tu cu.
        result.sort(Comparator.comparingInt(x -> vowelCount(x)));
        sk.submitCharacterStringArray(msv, qcode, result);
        System.out.println(result);
    }

    static int vowelCount(String s) {
        int count = 0;
        for (char c : s.toLowerCase(Locale.ROOT).toCharArray()) {
            if ("aeiou".indexOf(c) >= 0) count++;
        }
        return count;
    }
}
