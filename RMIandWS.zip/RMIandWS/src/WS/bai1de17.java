package WS;

import java.util.*;
import java.time.*;
import java.math.*;
import java.util.stream.*;

// De 17, bai 1 - Tinh ngay lam viec khong tinh thu bay CN
// qCode trong tai lieu on thi 2024-2025: L8CainEX
public class bai1de17 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "L8CainEX";
        SoapObjectService sk = new ObjectService().getPort(SoapObjectService.class);
        Employee e = sk.requestEmployee(msv, qcode);
        if (e == null) { System.out.println("Server tra ve null"); return; }
        LocalDate from = e.getStartDate().toGregorianCalendar().toZonedDateTime().toLocalDate();
        LocalDate to = e.getEndDate().toGregorianCalendar().toZonedDateTime().toLocalDate();
        int workingDays = 0;
        for (LocalDate d = from; !d.isAfter(to); d = d.plusDays(1)) {
            DayOfWeek weekDay = d.getDayOfWeek();
            if (weekDay != DayOfWeek.SATURDAY && weekDay != DayOfWeek.SUNDAY) workingDays++;
        }
        e.setWorkingDays(workingDays);
        sk.submitEmployee(msv, qcode, e);
        System.out.println("workingDays=" + workingDays);
    }
}
