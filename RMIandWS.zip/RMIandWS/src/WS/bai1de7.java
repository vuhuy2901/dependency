package WS;

import java.util.*;
import java.time.*;
import java.math.*;
import java.util.stream.*;

// De 7, bai 1 - Loai bo ky tu khong phai chu va dao nguoc
// qCode trong tai lieu on thi 2024-2025: rT6Ql5GH
public class bai1de7 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "rT6Ql5GH";
        SoapCharacterService sk = new CharacterService().getPort(SoapCharacterService.class);
        String s = sk.requestString(msv, qcode);
        if (s == null) { System.out.println("Server tra ve null"); return; }
        String clean = s.replaceAll("[^A-Za-z]", "");
        String result = new StringBuilder(clean).reverse().toString();
        sk.submitCharacterString(msv, qcode, result);
        System.out.println(result);
    }
}
