package WS;

import java.util.*;
import java.time.*;
import java.math.*;
import java.util.stream.*;

// De 8, bai 2 - Tu dai nhat va ngan nhat trong danh sach
// qCode trong tai lieu on thi 2024-2025: sGJc3iD5
public class bai2de8 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "sGJc3iD5";
        SoapCharacterService sk = new CharacterService().getPort(SoapCharacterService.class);
        List<String> a = sk.requestStringArray(msv, qcode);
        if (a == null || a.isEmpty()) { System.out.println("Khong co du lieu"); return; }
        String longest = a.get(0), shortest = a.get(0);
        for (String s : a) {
            if (s.length() > longest.length()) longest = s;
            if (s.length() < shortest.length()) shortest = s;
        }
        // De 8 vi du: "pineapple;fig" KHONG co dau cach sau dau ;
        String result = longest + ";" + shortest;
        sk.submitCharacterString(msv, qcode, result);
        System.out.println(result);
    }
}
