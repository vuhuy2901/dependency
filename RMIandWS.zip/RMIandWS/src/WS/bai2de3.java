package WS;

import java.util.*;
import java.time.*;
import java.math.*;
import java.util.stream.*;

// De 3, bai 2 - Sap xep tu theo do dai tang dan
// qCode trong tai lieu on thi 2024-2025: mpu9xCxR
public class bai2de3 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "mpu9xCxR";
        SoapCharacterService sk = new CharacterService().getPort(SoapCharacterService.class);
        List<String> a = sk.requestStringArray(msv, qcode);
        if (a == null) { System.out.println("Server tra ve null"); return; }
        List<String> result = new ArrayList<>(a);
        result.sort(Comparator.comparingInt(String::length)); // On dinh khi bang do dai
        sk.submitCharacterStringArray(msv, qcode, result);
        System.out.println(result);
    }
}
