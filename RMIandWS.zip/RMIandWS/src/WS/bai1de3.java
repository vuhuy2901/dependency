package WS;

import java.util.*;
import java.time.*;
import java.math.*;
import java.util.stream.*;

// De 3, bai 1 - Phan tu lon thu K va nho thu K
// qCode trong tai lieu on thi 2024-2025: WpaUTFMu
public class bai1de3 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "WpaUTFMu";
        SoapDataService sk = new DataService().getPort(SoapDataService.class);
        List<Integer> a = sk.getData(msv, qcode);
        if (a == null || a.size() < 2) { System.out.println("Khong co du lieu"); return; }
        int k = a.get(0);
        List<Integer> b = new ArrayList<>(a.subList(1, a.size()));
        Collections.sort(b);
        if (k < 1 || k > b.size()) { System.out.println("K khong hop le"); return; }
        List<Integer> result = Arrays.asList(b.get(b.size() - k), b.get(k - 1));
        sk.submitDataIntArray(msv, qcode, result);
        System.out.println(result);
    }
}
