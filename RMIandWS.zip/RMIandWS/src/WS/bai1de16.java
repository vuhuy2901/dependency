package WS;

import java.util.*;
import java.time.*;
import java.math.*;
import java.util.stream.*;

// De 16, bai 1 - Tinh tong cac so nguyen
// qCode trong tai lieu on thi 2024-2025: hnVAHv3I
public class bai1de16 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "hnVAHv3I";
        SoapDataService sk = new DataService().getPort(SoapDataService.class);
        List<Integer> a = sk.getData(msv, qcode);
        if (a == null) { System.out.println("Server tra ve null"); return; }
        int sum = 0;
        for (int x : a) sum += x;
        sk.submitDataInt(msv, qcode, sum);
        System.out.println("Tong: " + sum);
    }
}
