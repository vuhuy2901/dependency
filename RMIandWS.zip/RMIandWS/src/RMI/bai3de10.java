package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 10, bai 3: Caesar bytes theo do dai; qCode = i0EVI2TB
public class bai3de10 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "i0EVI2TB";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        ByteService sk = (ByteService) rg.lookup("RMIByteService");

        byte[] a = sk.requestData(msv, qcode);
        int shift = a.length;
        for (int i = 0; i < a.length; i++) a[i] = (byte)(a[i] + shift);
        sk.submitData(msv, qcode, a);
        System.out.println(Arrays.toString(a));
        // PDF co lech mot gia tri trong vi du, mo ta quy tac cong length vao moi byte.
    }
}
