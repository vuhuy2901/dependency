package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 16, bai 2: Ma hoa URL; qCode = KkihaRAB
public class bai2de16 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "KkihaRAB";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        CharacterService sk = (CharacterService) rg.lookup("RMICharacterService");

        String s = sk.requestCharacter(msv, qcode);
        String result = URLEncoder.encode(s, StandardCharsets.UTF_8)
                .replace("+", "%20").replace("%7E", "~").replace("*", "%2A");
        sk.submitCharacter(msv, qcode, result);
        System.out.println(result);
    }
}
