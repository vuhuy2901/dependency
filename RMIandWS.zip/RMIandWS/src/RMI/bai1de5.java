package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 5, bai 1: Liet ke so nguyen to; qCode = nD8MdtME
public class bai1de5 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "nD8MdtME";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        DataService sk = (DataService) rg.lookup("RMIDataService");

        int n = Integer.parseInt(sk.requestData(msv, qcode).toString().trim());
        ArrayList<Integer> result = new ArrayList<>();
        for (int i = 2; i <= n; i++) if (isPrime(i)) result.add(i);
        sk.submitData(msv, qcode, result);
        System.out.println(result);
    }

    static boolean isPrime(int n) {
        if (n < 2) return false;
        for (int d = 2; d <= n / d; d++) if (n % d == 0) return false;
        return true;
    }
}
