package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 3, bai 4: Tao code Book; qCode = nCOdwcKJ
public class bai4de3 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "nCOdwcKJ";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        ObjectService sk = (ObjectService) rg.lookup("RMIObjectService");

        Book b = (Book) sk.requestObject(msv, qcode);
        String[] name = b.getAuthor().trim().split("\s+");
        String initials = ("" + Character.toUpperCase(name[0].charAt(0))
                + Character.toUpperCase(name[name.length - 1].charAt(0)));
        int titleLetters = 0;
        for (char c : b.getTitle().toCharArray()) if (Character.isLetter(c)) titleLetters++;
        String code = initials + String.format("%02d", b.getYearPublished() % 100)
                + titleLetters + String.format("%03d", b.getPageCount());
        b.setCode(code);
        sk.submitObject(msv, qcode, b);
        System.out.println(code);
        // Canh bao: vi du "Pride and Prejudice" ghi 18 chu cai la khong nhat quan.
    }
}
