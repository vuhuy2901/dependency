package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 11, bai 4: Tao ma Event; qCode = FKrGvwLM
public class bai4de11 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "FKrGvwLM";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        ObjectService sk = (ObjectService) rg.lookup("RMIObjectService");

        Event e = (Event) sk.requestObject(msv, qcode);
        String name = e.getEventName().trim().toUpperCase(Locale.ROOT);
        String level = e.getExpectedAttendance() >= 1000 ? "L"
                : e.getExpectedAttendance() >= 500 ? "M" : "S";
        String[] date = e.getEventDate().split("[-/]"); // yyyy-MM-dd
        String code = level + name.charAt(0) + name.charAt(name.length() - 1)
                + date[2] + date[1]; // ddMM
        e.setEventCode(code);
        sk.submitObject(msv, qcode, e);
        System.out.println(code);
    }
}
