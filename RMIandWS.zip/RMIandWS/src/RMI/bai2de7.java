package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 7, bai 2: Ma hoa Vigenere; qCode = Y7YMXHs4
public class bai2de7 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "Y7YMXHs4";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        CharacterService sk = (CharacterService) rg.lookup("RMICharacterService");

        String s = sk.requestCharacter(msv, qcode);
        String[] parts = s.split(";", 2);
        String key = parts[0].toUpperCase(Locale.ROOT), text = parts[1];
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            int shift = (key.charAt(i % key.length()) - 'A' + 26) % 26;
            if (c >= 'A' && c <= 'Z') c = (char)('A' + (c - 'A' + shift) % 26);
            else if (c >= 'a' && c <= 'z') c = (char)('a' + (c - 'a' + shift) % 26);
            result.append(c);
        }
        sk.submitCharacter(msv, qcode, result.toString());
        System.out.println(result);
    }
}
