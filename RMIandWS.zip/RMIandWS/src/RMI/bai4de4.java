package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 4, bai 4: Tao code BookX; qCode = CoWosBho
public class bai4de4 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "CoWosBho";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        ObjectService sk = (ObjectService) rg.lookup("RMIObjectService");

        BookX b = (BookX) sk.requestObject(msv, qcode);
        String author = b.getAuthor().trim();
        char first = Character.toUpperCase(author.charAt(0));
        char last = Character.toLowerCase(author.charAt(author.length() - 1));
        int genreLetters = 0;
        for (char c : b.getGenre().toCharArray()) if (Character.isLetter(c)) genreLetters++;
        String code = "" + first + last
                + String.format("%02d", b.getYearPublished() % 100)
                + genreLetters + b.getTitle().length() % 10;
        b.setCode(code);
        sk.submitObject(msv, qcode, b);
        System.out.println(code);
    }
}
