package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 5, bai 3: Giai ma Base64 bytes; qCode = oeJljCIf
public class bai3de5 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "oeJljCIf";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        ByteService sk = (ByteService) rg.lookup("RMIByteService");

        byte[] encoded = sk.requestData(msv, qcode);
        byte[] result = Base64.getDecoder().decode(new String(encoded, StandardCharsets.US_ASCII).trim());
        sk.submitData(msv, qcode, result);
        System.out.println(Arrays.toString(result));
    }
}
