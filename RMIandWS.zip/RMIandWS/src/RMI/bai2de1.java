package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 1, bai 2: Xu ly JSON tach vi tri chan le; qCode = NFldNPp6
public class bai2de1 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "NFldNPp6";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        CharacterService sk = (CharacterService) rg.lookup("RMICharacterService");

        String s = sk.requestCharacter(msv, qcode);
        // JSON phang: chuoi, so, true/false/null (khong ho tro JSON long nhau).
        Pattern p = Pattern.compile("\\\"([^\\\"]+)\\\"\\s*:\\s*(\\\"([^\\\"]*)\\\"|[^,}\\s]+)");
        Matcher m = p.matcher(s);
        List<String> even = new ArrayList<>(), odd = new ArrayList<>();
        int index = 0;
        while (m.find()) {
            String value = m.group(3) == null ? m.group(2) : m.group(3);
            String pair = m.group(1) + ": " + value;
            (index++ % 2 == 0 ? even : odd).add(pair);
        }
        String result = String.join(", ", even) + "; " + String.join(", ", odd);
        sk.submitCharacter(msv, qcode, result);
        System.out.println(result);
    }
}
