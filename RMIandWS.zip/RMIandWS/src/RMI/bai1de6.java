package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 6, bai 1: Phuong sai va do lech chuan; qCode = uZMEY3Zg
public class bai1de6 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "uZMEY3Zg";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        DataService sk = (DataService) rg.lookup("RMIDataService");

        String s = sk.requestData(msv, qcode).toString();
        String[] parts = s.split("\s*,\s*");
        double[] a = new double[parts.length];
        double sum = 0;
        for (int i = 0; i < a.length; i++) {
            a[i] = Double.parseDouble(parts[i].trim());
            sum += a[i];
        }
        double mean = sum / a.length, variance = 0;
        for (double x : a) variance += (x - mean) * (x - mean);
        variance /= a.length;
        double stddev = Math.sqrt(variance);
        String result = String.format(Locale.US, "%.2f : %.2f", variance, stddev);
        sk.submitData(msv, qcode, result);
        System.out.println(result);
        // PDF noi "variance : standard deviation", nhung khong cho vi du chuoi output thuc te.
    }
}
