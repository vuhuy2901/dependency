package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 1, bai 4: Chuan hoa Product; qCode = dx3nt4Ij
public class bai4de1 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "dx3nt4Ij";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        ObjectService sk = (ObjectService) rg.lookup("RMIObjectService");

        Product p = (Product) sk.requestObject(msv, qcode);
        p.setCode(p.getCode().toUpperCase(Locale.ROOT));
        p.setExportPrice(p.getImportPrice() * 1.2);
        sk.submitObject(msv, qcode, p);
        System.out.println(p.getCode() + ": " + p.getExportPrice());
    }
}
