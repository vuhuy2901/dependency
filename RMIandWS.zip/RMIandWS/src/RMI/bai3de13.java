package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 13, bai 3: Nen RLE byte; qCode = 2uG0lQGi
public class bai3de13 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "2uG0lQGi";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        ByteService sk = (ByteService) rg.lookup("RMIByteService");

        byte[] a = sk.requestData(msv, qcode);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        for (int i = 0; i < a.length; ) {
            int j = i + 1;
            while (j < a.length && a[j] == a[i] && j - i < 255) j++;
            out.write(a[i]);
            out.write(j - i);
            i = j;
        }
        byte[] result = out.toByteArray();
        sk.submitData(msv, qcode, result);
        System.out.println(Arrays.toString(result));
    }
}
