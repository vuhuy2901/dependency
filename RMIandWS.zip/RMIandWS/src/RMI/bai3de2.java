package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 2, bai 3: Byte xuat hien it nhat; qCode = L7A2NPQU
public class bai3de2 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "L7A2NPQU";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        ByteService sk = (ByteService) rg.lookup("RMIByteService");

        byte[] a = sk.requestData(msv, qcode);
        int[] count = new int[256];
        for (byte x : a) count[x & 255]++;
        int best = 0;
        for (int i = 1; i < a.length; i++) {
            if (count[a[i] & 255] < count[a[best] & 255]) best = i;
        }
        byte[] result = { a[best], (byte)count[a[best] & 255] };
        sk.submitData(msv, qcode, result);
        System.out.println(Arrays.toString(result));
    }
}
