package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 17, bai 3: Byte phan tu lon thu K va vi tri; qCode = uIKHCTWG
public class bai3de17 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "uIKHCTWG";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        ByteService sk = (ByteService) rg.lookup("RMIByteService");

        byte[] a = sk.requestData(msv, qcode);
        int k = a[a.length - 1] & 255; // phan tu CUOI la k, khong tinh khi xep hang
        int[] nums = new int[a.length - 1];
        for (int i = 0; i < nums.length; i++) nums[i] = a[i];
        int[] sorted = nums.clone();
        Arrays.sort(sorted);
        int target = sorted[sorted.length - k];
        int position = -1;
        for (int i = 0; i < nums.length; i++) {
            if (nums[i] == target) { position = i + 1; break; } // 1-based
        }
        byte[] result = { (byte)target, (byte)position };
        sk.submitData(msv, qcode, result);
        System.out.println(Arrays.toString(result));
        // De ghi "vi tri cua K" mo ho: o day la vi tri gia tri lon thu K trong mang goc.
    }
}
