package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 12, bai 3: Byte sang chuoi hex; qCode = pK0IZNnt
public class bai3de12 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "pK0IZNnt";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        ByteService sk = (ByteService) rg.lookup("RMIByteService");

        byte[] a = sk.requestData(msv, qcode);
        StringBuilder hex = new StringBuilder();
        for (byte b : a) hex.append(String.format("%02x", b & 255));
        byte[] result = hex.toString().getBytes(StandardCharsets.US_ASCII);
        sk.submitData(msv, qcode, result);
        System.out.println(hex);
    }
}
