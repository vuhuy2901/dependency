package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 11, bai 2: Ma hoa Base64 chuoi; qCode = psd4Jmnt
public class bai2de11 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "psd4Jmnt";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        CharacterService sk = (CharacterService) rg.lookup("RMICharacterService");

        String s = sk.requestCharacter(msv, qcode);
        String result = Base64.getEncoder().encodeToString(s.getBytes(StandardCharsets.UTF_8));
        sk.submitCharacter(msv, qcode, result);
        System.out.println(result);
    }
}
