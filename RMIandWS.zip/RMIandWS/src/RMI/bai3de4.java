package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 4, bai 3: XOR bytes voi PTIT; qCode = 4BraNTI5
public class bai3de4 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "4BraNTI5";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        ByteService sk = (ByteService) rg.lookup("RMIByteService");

        byte[] a = sk.requestData(msv, qcode);
        byte[] key = "PTIT".getBytes(StandardCharsets.US_ASCII);
        for (int i = 0; i < a.length; i++) a[i] = (byte)(a[i] ^ key[i % key.length]);
        sk.submitData(msv, qcode, a);
        System.out.println(Arrays.toString(a));
    }
}
