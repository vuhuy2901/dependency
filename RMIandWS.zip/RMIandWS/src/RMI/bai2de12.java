package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 12, bai 2: Thap phan sang La Ma; qCode = ADu6zRYE
public class bai2de12 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "ADu6zRYE";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        CharacterService sk = (CharacterService) rg.lookup("RMICharacterService");

        int n = Integer.parseInt(sk.requestCharacter(msv, qcode).trim());
        int[] values = {1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
        String[] romans = {"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < values.length; i++) {
            while (n >= values[i]) {
                result.append(romans[i]);
                n -= values[i];
            }
        }
        sk.submitCharacter(msv, qcode, result.toString());
        System.out.println(result);
    }
}
