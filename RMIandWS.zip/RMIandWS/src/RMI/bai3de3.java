package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 3, bai 3: Byte sang chuoi bat phan 3 chu so; qCode = HhPAxeDw
public class bai3de3 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "HhPAxeDw";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        ByteService sk = (ByteService) rg.lookup("RMIByteService");

        byte[] a = sk.requestData(msv, qcode);
        StringBuilder oct = new StringBuilder();
        for (byte x : a) oct.append(String.format("%03o", x & 255));
        byte[] result = oct.toString().getBytes(StandardCharsets.US_ASCII);
        sk.submitData(msv, qcode, result);
        System.out.println(oct);
    }
}
