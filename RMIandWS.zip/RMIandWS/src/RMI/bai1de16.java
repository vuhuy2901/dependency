package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 16, bai 1: Sinh to hop chap K; qCode = juC3u7C6
public class bai1de16 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "juC3u7C6";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        DataService sk = (DataService) rg.lookup("RMIDataService");

        String s = sk.requestData(msv, qcode).toString();
        String[] parts = s.split(";", 2);
        String[] nums = parts[0].replace("[", "").replace("]", "").trim().split("\s*,\s*");
        int k = Integer.parseInt(parts[1].trim());
        ArrayList<Integer> values = new ArrayList<>();
        for (String x : nums) values.add(Integer.parseInt(x.trim()));
        ArrayList<ArrayList<Integer>> result = new ArrayList<>();
        combine(values, k, 0, new ArrayList<>(), result);
        sk.submitData(msv, qcode, result); // Gui LIST long nhau, KHONG phai String
        System.out.println(result);
    }

    static void combine(List<Integer> values, int k, int start,
                        ArrayList<Integer> current, ArrayList<ArrayList<Integer>> result) {
        if (current.size() == k) {
            result.add(new ArrayList<>(current));
            return;
        }
        for (int i = start; i <= values.size() - (k - current.size()); i++) {
            current.add(values.get(i));
            combine(values, k, i + 1, current, result);
            current.remove(current.size() - 1);
        }
    }
}
