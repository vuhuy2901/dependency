package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 4, bai 2: Dem ky tu dinh dang Map; qCode = ctRfIejL
public class bai2de4 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "ctRfIejL";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        CharacterService sk = (CharacterService) rg.lookup("RMICharacterService");

        String s = sk.requestCharacter(msv, qcode);
        Map<Character, Integer> count = new LinkedHashMap<>();
        for (char c : s.toCharArray()) count.put(c, count.getOrDefault(c, 0) + 1);
        StringJoiner join = new StringJoiner(", ", "{", "}");
        for (Map.Entry<Character, Integer> e : count.entrySet()) {
            String key = String.valueOf(e.getKey()).replace("\\", "\\\\").replace("\"", "\\\"");
            join.add("\"" + key + "\": " + e.getValue());
        }
        String result = join.toString();
        sk.submitCharacter(msv, qcode, result);
        System.out.println(result);
        // De chi cho VI DU dinh dang kieu Map, khong quy dinh dau cach bat buoc.
    }
}
