package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 1, bai 1: Bo ba so Pytago; qCode = NMATI6Zw
public class bai1de1 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "NMATI6Zw";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        DataService sk = (DataService) rg.lookup("RMIDataService");

        Object raw = sk.requestData(msv, qcode);
        int n = Integer.parseInt(raw.toString().trim());
        ArrayList<ArrayList<Integer>> result = new ArrayList<>();
        for (int a = 1; a <= n; a++) {
            for (int b = a + 1; b <= n; b++) {
                long c2 = (long)a * a + (long)b * b;
                int c = (int)Math.sqrt(c2);
                if (c > b && c <= n && (long)c * c == c2) {
                    // Vi du goc N=20 chi liet ke bo ba nguyen thuy.
                    // Neu may cham yeu cau TAT CA bo ba, bo dieu kien gcd(a,b)==1.
                    if (gcd(a, b) == 1) {
                        result.add(new ArrayList<>(Arrays.asList(a, b, c)));
                    }
                }
            }
        }
        sk.submitData(msv, qcode, result);
        System.out.println(result);
    }

    static int gcd(int a, int b) {
        while (b != 0) { int t = a % b; a = b; b = t; }
        return a;
    }
}
