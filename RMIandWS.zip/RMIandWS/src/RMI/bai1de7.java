package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 7, bai 1: Liet ke so doi xung N den K; qCode = t3cBY2uk
public class bai1de7 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "t3cBY2uk";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        DataService sk = (DataService) rg.lookup("RMIDataService");

        String s = sk.requestData(msv, qcode).toString();
        String[] parts = s.split(";");
        int n = Integer.parseInt(parts[0].trim());
        int k = Integer.parseInt(parts[1].trim());
        ArrayList<Integer> result = new ArrayList<>();
        for (int i = n; i < k; i++) {
            String x = String.valueOf(i);
            if (x.equals(new StringBuilder(x).reverse().toString())) result.add(i);
        }
        sk.submitData(msv, qcode, result);
        System.out.println(result);
    }
}
