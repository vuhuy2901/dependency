package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 2, bai 1: Hoan vi ke tiep; qCode = 3Qe0Qb5w
public class bai1de2 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "3Qe0Qb5w";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        DataService sk = (DataService) rg.lookup("RMIDataService");

        String s = sk.requestData(msv, qcode).toString();
        String[] parts = s.replace("[", "").replace("]", "").trim().split("\s*,\s*");
        int[] a = new int[parts.length];
        for (int i = 0; i < a.length; i++) a[i] = Integer.parseInt(parts[i].trim());
        int i = a.length - 2;
        while (i >= 0 && a[i] >= a[i + 1]) i--;
        if (i >= 0) {
            int j = a.length - 1;
            while (a[j] <= a[i]) j--;
            int tmp = a[i]; a[i] = a[j]; a[j] = tmp;
        }
        for (int l = i + 1, r = a.length - 1; l < r; l++, r--) {
            int tmp = a[l]; a[l] = a[r]; a[r] = tmp;
        }
        StringJoiner sj = new StringJoiner(",");
        for (int x : a) sj.add(String.valueOf(x));
        String result = sj.toString();
        sk.submitData(msv, qcode, result);
        System.out.println(result);
    }
}
