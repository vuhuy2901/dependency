package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 8, bai 2: Giai ma Caesar; qCode = j4rStb2a
public class bai2de8 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "j4rStb2a";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        CharacterService sk = (CharacterService) rg.lookup("RMICharacterService");

        String s = sk.requestCharacter(msv, qcode);
        int shift = s.length() % 7;
        StringBuilder result = new StringBuilder();
        for (char c : s.toCharArray()) {
            if (c >= 'A' && c <= 'Z') c = (char)('A' + (c - 'A' - shift + 26) % 26);
            else if (c >= 'a' && c <= 'z') c = (char)('a' + (c - 'a' - shift + 26) % 26);
            result.append(c);
        }
        sk.submitCharacter(msv, qcode, result.toString());
        System.out.println(result);
        // De ghi "giai ma" nhung khong cho vi du; dang dung phep dich lui.
    }
}
