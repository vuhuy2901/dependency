package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 7, bai 4: Tao ma Order; qCode = vLJWvWpf
public class bai4de7 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "vLJWvWpf";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        ObjectService sk = (ObjectService) rg.lookup("RMIObjectService");

        Order o = (Order) sk.requestObject(msv, qcode);
        String ship = o.getShippingType().toUpperCase(Locale.ROOT);
        String customer = o.getCustomerCode();
        String[] date = o.getOrderDate().split("[-/]"); // yyyy-MM-dd
        String code = ship.substring(0, 2)
                + customer.substring(customer.length() - 3)
                + date[2] + date[1]; // ddMM
        o.setOrderCode(code);
        sk.submitObject(msv, qcode, o);
        System.out.println(code);
    }
}
