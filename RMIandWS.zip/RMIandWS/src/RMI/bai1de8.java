package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 8, bai 1: Phan tich thua so nguyen to; qCode = zzmmquoc
public class bai1de8 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "zzmmquoc";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        DataService sk = (DataService) rg.lookup("RMIDataService");

        long n = Long.parseLong(sk.requestData(msv, qcode).toString().trim());
        ArrayList<Long> result = new ArrayList<>();
        for (long d = 2; d <= n / d; d++) {
            while (n % d == 0) {
                result.add(d);
                n /= d;
            }
        }
        if (n > 1) result.add(n);
        sk.submitData(msv, qcode, result);
        System.out.println(result);
        // Neu server doi List<Integer> thay vi List<Long>, chuyen cac phan tu ve Integer.
    }
}
