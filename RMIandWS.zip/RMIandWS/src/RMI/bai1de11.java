package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 11, bai 1: Sap xep byte chan truoc le sau; qCode = A7hytb1V
public class bai1de11 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "A7hytb1V";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        ByteService sk = (ByteService) rg.lookup("RMIByteService");

        byte[] a = sk.requestData(msv, qcode);
        byte[] result = new byte[a.length];
        int j = 0;
        for (byte x : a) if (x % 2 == 0) result[j++] = x;
        for (byte x : a) if (x % 2 != 0) result[j++] = x;
        sk.submitData(msv, qcode, result);
        System.out.println(Arrays.toString(result));
    }
}
