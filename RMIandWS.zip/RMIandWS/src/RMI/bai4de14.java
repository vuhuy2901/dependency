package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 14, bai 4: Tinh luong Employee; qCode = 7fSWnlHB
public class bai4de14 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "7fSWnlHB";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        ObjectService sk = (ObjectService) rg.lookup("RMIObjectService");

        Employee e = (Employee) sk.requestObject(msv, qcode);
        int years = e.getExperienceYears();
        int digitSum = 0, t = Math.abs(years);
        do { digitSum += t % 10; t /= 10; } while (t > 0);
        int divisors = 0;
        for (int d = 1; d <= years; d++) if (years % d == 0) divisors++;
        double factor = (years + digitSum + divisors) / 100.0;
        e.setFinalSalary(e.getBaseSalary() * (1 + factor));
        sk.submitObject(msv, qcode, e);
        System.out.println(e.getFinalSalary());
    }
}
