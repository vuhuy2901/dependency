package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 3, bai 1: Phan tu lon thu K Data; qCode = wzG6G9ji
public class bai1de3 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "wzG6G9ji";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        DataService sk = (DataService) rg.lookup("RMIDataService");

        String s = sk.requestData(msv, qcode).toString();
        String[] two = s.split(";", 2);
        String[] nums = two[0].trim().split("\s*,\s*");
        int k = Integer.parseInt(two[1].trim());
        int[] a = new int[nums.length];
        for (int i = 0; i < a.length; i++) a[i] = Integer.parseInt(nums[i].trim());
        Arrays.sort(a);
        int result = a[a.length - k];
        sk.submitData(msv, qcode, result);
        System.out.println(result);
    }
}
