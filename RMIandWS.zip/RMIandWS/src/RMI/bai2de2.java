package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 2, bai 2: Dem tan so ky tu dang A3B2C1; qCode = U5BEBBOW
public class bai2de2 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "U5BEBBOW";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        CharacterService sk = (CharacterService) rg.lookup("RMICharacterService");

        String s = sk.requestCharacter(msv, qcode);
        Map<Character, Integer> count = new LinkedHashMap<>();
        for (char c : s.toCharArray()) count.put(c, count.getOrDefault(c, 0) + 1);
        StringBuilder result = new StringBuilder();
        for (Map.Entry<Character, Integer> e : count.entrySet()) {
            result.append(e.getKey()).append(e.getValue());
        }
        sk.submitCharacter(msv, qcode, result.toString());
        System.out.println(result);
    }
}
