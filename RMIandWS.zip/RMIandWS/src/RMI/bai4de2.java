package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 2, bai 4: Tinh giam gia ProductX; qCode = PY43T66m
public class bai4de2 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "PY43T66m";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        ObjectService sk = (ObjectService) rg.lookup("RMIObjectService");

        ProductX p = (ProductX) sk.requestObject(msv, qcode);
        int discount = 0;
        for (char c : p.getDiscountCode().toCharArray()) {
            if (Character.isDigit(c)) discount += c - '0';
        }
        p.setDiscount(discount);
        sk.submitObject(msv, qcode, p);
        System.out.println(discount);
    }
}
