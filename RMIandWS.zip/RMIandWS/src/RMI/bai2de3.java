package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 3, bai 2: XOR chuoi voi khoa lap; qCode = Xidb0Thk
public class bai2de3 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "Xidb0Thk";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        CharacterService sk = (CharacterService) rg.lookup("RMICharacterService");

        String s = sk.requestCharacter(msv, qcode);
        String[] p = s.split(";", 2);
        String key = p[0], input = p[1];
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < input.length(); i++) {
            result.append((char)(input.charAt(i) ^ key.charAt(i % key.length())));
        }
        sk.submitCharacter(msv, qcode, result.toString());
        System.out.println(result);
        // Vi du "A;HELLO" -> "IFMMN" trong PDF KHONG khop XOR ky tu; can kiem tra dap an server.
    }
}
