package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 9, bai 4: Tao ma va chuan hoa Student; qCode = lNV6xzmk
public class bai4de9 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "lNV6xzmk";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        ObjectService sk = (ObjectService) rg.lookup("RMIObjectService");

        Student st = (Student) sk.requestObject(msv, qcode);
        String[] words = st.getName().trim().toLowerCase(Locale.ROOT).split("\s+");
        StringBuilder clean = new StringBuilder();
        for (String w : words) {
            if (clean.length() > 0) clean.append(' ');
            clean.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));
        }
        StringBuilder initials = new StringBuilder();
        for (int i = 0; i < words.length - 1; i++) {
            initials.append(Character.toUpperCase(words[i].charAt(0)));
        }
        String lastName = words[words.length - 1].toUpperCase(Locale.ROOT);
        String code = "B" + String.format("%02d", st.getEnrollmentYear() % 100)
                + lastName + "_" + initials;
        st.setName(clean.toString());
        st.setCode(code);
        sk.submitObject(msv, qcode, st);
        System.out.println(st.getName() + " -> " + code);
        // PDF co vi du ghi "TUAN" trong ten chuan hoa, mau khac voi mo ta viet hoa chu cai dau.
    }
}
