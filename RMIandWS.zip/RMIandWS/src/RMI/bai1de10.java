package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 10, bai 1: Liet ke so chinh phuong < N; qCode = eTHcAYZh
public class bai1de10 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "eTHcAYZh";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        DataService sk = (DataService) rg.lookup("RMIDataService");

        int n = Integer.parseInt(sk.requestData(msv, qcode).toString().trim());
        ArrayList<Integer> result = new ArrayList<>();
        for (int i = 1; (long)i * i < n; i++) result.add(i * i);
        sk.submitData(msv, qcode, result);
        System.out.println(result);
    }
}
