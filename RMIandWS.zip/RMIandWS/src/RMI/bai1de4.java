package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 4, bai 1: Doi tien 1 2 5 10; qCode = Iz06p8Zw
public class bai1de4 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "Iz06p8Zw";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        DataService sk = (DataService) rg.lookup("RMIDataService");

        int amount = Integer.parseInt(sk.requestData(msv, qcode).toString().trim());
        int[] denom = {10, 5, 2, 1};
        List<String> coins = new ArrayList<>();
        int remaining = amount;
        for (int coin : denom) {
            while (remaining >= coin) {
                coins.add(String.valueOf(coin));
                remaining -= coin;
            }
        }
        String result = remaining == 0 ? coins.size() + "; " + String.join(",", coins) : "-1";
        sk.submitData(msv, qcode, result);
        System.out.println(result);
    }
}
