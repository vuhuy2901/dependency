package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 5, bai 2: La Ma sang thap phan; qCode = 0JaasIw6
public class bai2de5 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "0JaasIw6";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        CharacterService sk = (CharacterService) rg.lookup("RMICharacterService");

        String s = sk.requestCharacter(msv, qcode).trim().toUpperCase(Locale.ROOT);
        int result = 0;
        for (int i = 0; i < s.length(); i++) {
            int x = roman(s.charAt(i));
            int next = (i + 1 < s.length()) ? roman(s.charAt(i + 1)) : 0;
            result += x < next ? -x : x;
        }
        sk.submitCharacter(msv, qcode, String.valueOf(result));
        System.out.println(result);
    }

    static int roman(char c) {
        switch (c) {
            case 'I': return 1;
            case 'V': return 5;
            case 'X': return 10;
            case 'L': return 50;
            case 'C': return 100;
            case 'D': return 500;
            case 'M': return 1000;
            default: throw new IllegalArgumentException("Invalid Roman digit: " + c);
        }
    }
}
