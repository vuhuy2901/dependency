package RMI;

import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;
import java.util.regex.*;

// De 15, bai 4: Tao ticketCode; qCode = Uct8bABt
public class bai4de15 {
    public static void main(String[] args) throws Exception {
        String msv = "B23DCCN959";
        String qcode = "Uct8bABt";
        Registry rg = LocateRegistry.getRegistry("36.50.135.242", 1099);
        ObjectService sk = (ObjectService) rg.lookup("RMIObjectService");

        Ticket t = (Ticket) sk.requestObject(msv, qcode);
        String eventName = t.getEventName().trim().toUpperCase(Locale.ROOT);
        String date = t.getSaleDate(); // dd/MM/yyyy theo vi du
        String[] parts = date.split("[-/]");
        String monthDay;
        if (parts[0].length() == 4) monthDay = parts[1] + parts[2]; // yyyy-MM-dd
        else monthDay = parts[1] + parts[0]; // dd/MM/yyyy
        boolean[] has = new boolean[10];
        for (char c : date.toCharArray()) if (Character.isDigit(c)) has[c - '0'] = true;
        int smallest = -1, largest = -1;
        for (int i = 0; i <= 9; i++) if (!has[i]) {
            if (smallest == -1) smallest = i;
            largest = i;
        }
        String code = "" + eventName.charAt(0) + eventName.charAt(eventName.length()-1)
                + monthDay + largest + smallest;
        t.setTicketCode(code);
        sk.submitObject(msv, qcode, t);
        System.out.println(code);
    }
}
